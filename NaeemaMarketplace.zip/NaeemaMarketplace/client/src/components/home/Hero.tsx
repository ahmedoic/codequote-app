import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import heroImage from "@assets/generated_images/high-end_modern_barbershop_interior_with_warm_lighting.png";
import { motion } from "framer-motion";

export function Hero() {
  return (
    <div className="relative overflow-hidden bg-background pt-16 md:pt-20 lg:pt-24">
      <div className="container relative z-10 px-4 md:px-8">
        <div className="mx-auto max-w-4xl text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-4xl font-bold tracking-tight text-foreground sm:text-6xl mb-6"
          >
            مستقبل العناية الشخصية <br />
            <span className="text-primary">في مكان واحد</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-muted-foreground mb-10"
          >
            منصة "نعيماً" تجمع العملاء، الصالونات، والموردين في سوق رقمي متكامل. اكتشف أفضل خدمات الحلاقة، أدر أعمالك بذكاء، ووسّع نطاق مبيعاتك.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="flex flex-wrap items-center justify-center gap-4"
          >
            <Button size="lg" className="text-lg h-12 px-8 shadow-lg shadow-primary/20">
              ابدأ رحلتك
              <ArrowLeft className="mr-2 h-5 w-5" />
            </Button>
            <Button variant="outline" size="lg" className="text-lg h-12 px-8">
              تعرف علينا
            </Button>
          </motion.div>
        </div>
      </div>
      
      <motion.div 
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.6 }}
        className="relative mt-16 sm:mt-24"
      >
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent z-10 h-32 -mt-32 top-0" />
        <div className="relative aspect-[16/9] w-full max-w-6xl mx-auto rounded-t-3xl overflow-hidden shadow-2xl border-t border-x border-border/50 bg-card">
           <img 
            src={heroImage} 
            alt="Modern Barbershop" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-primary/10 mix-blend-overlay" />
        </div>
      </motion.div>
    </div>
  );
}
