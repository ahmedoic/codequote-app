import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User, Scissors, Truck, ArrowLeft } from "lucide-react";
import customerImage from "@assets/generated_images/confident_saudi_man_smiling_after_a_haircut.png";
import barberImage from "@assets/generated_images/barber_using_a_smartphone_app.png";
import supplierImage from "@assets/generated_images/premium_grooming_products_arranged_neatly.png";
import { motion } from "framer-motion";

const stakeholders = [
  {
    id: "customers",
    title: "للعملاء",
    icon: User,
    description: "تجربة حلاقة مضمونة، سهلة، وشفافة.",
    features: ["اكتشاف أفضل الصالونات", "حجز مواعيد فورية", "تقييمات موثوقة", "دفع آمن"],
    image: customerImage,
    color: "text-primary",
    bgColor: "bg-primary/5",
  },
  {
    id: "partners",
    title: "للحلاقين والصالونات",
    icon: Scissors,
    description: "نظام متكامل لإدارة الأعمال والنمو.",
    features: ["إدارة الحجوزات", "تسويق للخدمات", "إدارة العملاء", "تقارير مالية"],
    image: barberImage,
    color: "text-secondary",
    bgColor: "bg-secondary/10",
  },
  {
    id: "suppliers",
    title: "للموردين",
    icon: Truck,
    description: "قناة تسويق ومبيعات مباشرة (B2B).",
    features: ["وصول مباشر للصالونات", "إدارة الطلبات", "تحليل السوق", "توسع في المبيعات"],
    image: supplierImage,
    color: "text-blue-600",
    bgColor: "bg-blue-50",
  },
];

export function Stakeholders() {
  return (
    <section className="py-24 bg-muted/30" id="stakeholders">
      <div className="container px-4 md:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">حلول متكاملة لكل الأطراف</h2>
          <p className="text-lg text-muted-foreground">
            منصة "نعيماً" تصنع بيئة رقمية تربط جميع أطراف قطاع العناية الشخصية لتعزيز الجودة والشفافية والنمو.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {stakeholders.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
            >
              <Card className="h-full flex flex-col overflow-hidden border-transparent shadow-lg hover:shadow-xl transition-shadow duration-300">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={item.image} 
                    alt={item.title} 
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                    <div className={`p-2 rounded-lg bg-background/90 backdrop-blur shadow-sm ${item.color}`}>
                      <item.icon className="w-6 h-6" />
                    </div>
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-2xl">{item.title}</CardTitle>
                  <CardDescription className="text-base mt-2">
                    {item.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  <ul className="space-y-3 mb-8 flex-1">
                    {item.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <div className={`w-1.5 h-1.5 rounded-full ${item.color.replace('text-', 'bg-')}`} />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button variant="ghost" className={`w-full justify-between group ${item.bgColor} hover:${item.bgColor}`}>
                    المزيد من التفاصيل
                    <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
