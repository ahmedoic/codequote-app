import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { ArrowRight, Upload, Check, Calculator } from "lucide-react";
import { Link } from "wouter";

const formSchema = z.object({
  projectType: z.string().min(1, "Please select a project type"),
  screens: z.number().min(1, "At least 1 screen is required"),
  integrations: z.array(z.string()).default([]),
  description: z.string().min(10, "Please provide a brief description"),
  timeline: z.string().min(1, "Please select a timeline"),
  budget: z.string().optional(),
  email: z.string().email("Please enter a valid email"),
  name: z.string().min(2, "Name is required"),
});

export default function RequestForm() {
  const { toast } = useToast();
  const [submitted, setSubmitted] = useState(false);
  const [estimatedCost, setEstimatedCost] = useState<number | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      projectType: "",
      screens: 5,
      integrations: [],
      description: "",
      timeline: "",
      budget: "",
      email: "",
      name: "",
    },
  });

  // Mock pricing logic for real-time estimation
  const calculateEstimate = (values: any) => {
    let base = 500; // Setup fee
    
    // Project type multiplier
    const typeMultipliers: Record<string, number> = {
      "web-app": 1.0,
      "mobile-app": 1.3,
      "landing-page": 0.5,
      "backend-api": 0.8,
    };
    
    const multiplier = typeMultipliers[values.projectType] || 1;
    
    // Screen cost
    const screenCost = values.screens * 200;
    
    // Integrations
    const integrationCost = (values.integrations?.length || 0) * 300;
    
    const total = (base + screenCost + integrationCost) * multiplier;
    setEstimatedCost(Math.round(total));
  };

  function onSubmit(values: z.infer<typeof formSchema>) {
    console.log(values);
    setTimeout(() => {
      setSubmitted(true);
      toast({
        title: "Request Sent!",
        description: "We've received your project details. You'll receive a formal quote shortly.",
      });
    }, 1000);
  }

  const integrationsList = [
    { id: "auth", label: "User Authentication" },
    { id: "payments", label: "Payment Processing" },
    { id: "maps", label: "Maps & Geolocation" },
    { id: "cms", label: "CMS Integration" },
    { id: "analytics", label: "Analytics" },
    { id: "email", label: "Email Notifications" },
  ];

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="mx-auto w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <Check className="h-6 w-6 text-green-600" />
            </div>
            <CardTitle>Request Received</CardTitle>
            <CardDescription>
              Thanks for submitting your project details. We'll review them and get back to you with a formal quote.
            </CardDescription>
          </CardHeader>
          <CardFooter className="flex justify-center">
            <Button variant="outline" onClick={() => setSubmitted(false)}>Submit Another Request</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 sm:text-4xl">Start Your Project</h1>
          <p className="mt-4 text-lg text-gray-600">
            Tell us about your idea and get an instant estimate.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form Section */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Project Details</CardTitle>
                <CardDescription>Fill in the specifications for your project.</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Your Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input placeholder="john@example.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="projectType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Project Type</FormLabel>
                          <Select 
                            onValueChange={(val) => {
                              field.onChange(val);
                              calculateEstimate({ ...form.getValues(), projectType: val });
                            }} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a project type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="web-app">Web Application (SaaS)</SelectItem>
                              <SelectItem value="mobile-app">Mobile App (iOS/Android)</SelectItem>
                              <SelectItem value="landing-page">Marketing / Landing Page</SelectItem>
                              <SelectItem value="backend-api">Backend API Only</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="screens"
                      render={({ field }) => (
                        <FormItem>
                          <div className="flex justify-between items-center">
                            <FormLabel>Number of Screens / Pages</FormLabel>
                            <span className="text-sm font-medium text-gray-500">{field.value}</span>
                          </div>
                          <FormControl>
                            <Slider
                              min={1}
                              max={30}
                              step={1}
                              defaultValue={[field.value]}
                              onValueChange={(vals) => {
                                field.onChange(vals[0]);
                                calculateEstimate({ ...form.getValues(), screens: vals[0] });
                              }}
                            />
                          </FormControl>
                          <FormDescription>Estimate the number of unique views needed.</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="integrations"
                      render={() => (
                        <FormItem>
                          <div className="mb-4">
                            <FormLabel className="text-base">Required Integrations</FormLabel>
                            <FormDescription>Select the capabilities you need.</FormDescription>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {integrationsList.map((item) => (
                              <FormField
                                key={item.id}
                                control={form.control}
                                name="integrations"
                                render={({ field }) => {
                                  return (
                                    <FormItem
                                      key={item.id}
                                      className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-3 hover:bg-gray-50 transition-colors"
                                    >
                                      <FormControl>
                                        <Checkbox
                                          checked={field.value?.includes(item.id)}
                                          onCheckedChange={(checked) => {
                                            const current = field.value || [];
                                            const updated = checked
                                              ? [...current, item.id]
                                              : current.filter((value) => value !== item.id);
                                            field.onChange(updated);
                                            calculateEstimate({ ...form.getValues(), integrations: updated });
                                          }}
                                        />
                                      </FormControl>
                                      <FormLabel className="font-normal cursor-pointer w-full">
                                        {item.label}
                                      </FormLabel>
                                    </FormItem>
                                  )
                                }}
                              />
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="timeline"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Desired Timeline</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="When do you need this?" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="urgent">Urgent (ASAP)</SelectItem>
                              <SelectItem value="1-month">Within 1 month</SelectItem>
                              <SelectItem value="3-months">1-3 months</SelectItem>
                              <SelectItem value="flexible">Flexible</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Project Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe your project in detail..." 
                              className="min-h-[120px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button type="submit" className="w-full" size="lg">
                      Submit Request <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>

          {/* Estimation Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-8">
              <Card className="bg-slate-900 text-white border-slate-800 shadow-xl overflow-hidden">
                <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-blue-500 rounded-full opacity-20 blur-xl"></div>
                <CardHeader>
                  <CardTitle className="flex items-center text-white">
                    <Calculator className="mr-2 h-5 w-5" />
                    Live Estimate
                  </CardTitle>
                  <CardDescription className="text-slate-400">
                    Ballpark cost based on your selections.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="text-center py-6 border-b border-slate-800">
                      <span className="text-slate-400 text-sm uppercase tracking-wider font-medium">Estimated Range</span>
                      <div className="text-4xl font-bold mt-2 text-white">
                        {estimatedCost ? `$${estimatedCost.toLocaleString()}` : "$0"}
                      </div>
                      <div className="text-sm text-slate-400 mt-1">
                        {estimatedCost ? `to $${Math.round(estimatedCost * 1.2).toLocaleString()}` : "Select options to see price"}
                      </div>
                    </div>

                    <div className="space-y-2 text-sm text-slate-300">
                      <div className="flex justify-between">
                        <span>Base Setup</span>
                        <span>$500</span>
                      </div>
                      {form.watch("screens") > 0 && (
                        <div className="flex justify-between">
                          <span>{form.watch("screens")} Screens</span>
                          <span>+${(form.watch("screens") * 200).toLocaleString()}</span>
                        </div>
                      )}
                      {form.watch("integrations")?.length > 0 && (
                        <div className="flex justify-between">
                          <span>{form.watch("integrations")?.length} Integrations</span>
                          <span>+${((form.watch("integrations")?.length || 0) * 300).toLocaleString()}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="bg-blue-900/30 p-3 rounded-md text-xs text-blue-200 mt-4 border border-blue-900/50">
                      * This is a rough estimate. Final quote may vary based on specific requirements and complexity.
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <div className="mt-6 text-center">
                <Link href="/" className="text-sm text-gray-500 hover:text-gray-800 underline">
                  Back to Home
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
