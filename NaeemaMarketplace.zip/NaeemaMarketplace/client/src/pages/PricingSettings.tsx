import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Save, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function PricingSettings() {
  const { toast } = useToast();
  const [hourlyRate, setHourlyRate] = useState(85);
  
  const handleSave = () => {
    toast({
      title: "Settings Saved",
      description: "Your pricing configuration has been updated.",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Pricing Configuration</h1>
              <p className="text-gray-500">Manage how your estimates are calculated.</p>
            </div>
          </div>
          <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">
            <Save className="h-4 w-4 mr-2" />
            Save Changes
          </Button>
        </div>

        <Tabs defaultValue="general" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="general">General Rates</TabsTrigger>
            <TabsTrigger value="multipliers">Project Multipliers</TabsTrigger>
            <TabsTrigger value="integrations">Integration Costs</TabsTrigger>
          </TabsList>
          
          <TabsContent value="general">
            <Card>
              <CardHeader>
                <CardTitle>Base Rates</CardTitle>
                <CardDescription>Set your standard hourly rate and base fees.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Hourly Rate ($)</Label>
                    <Input 
                      type="number" 
                      value={hourlyRate} 
                      onChange={(e) => setHourlyRate(Number(e.target.value))} 
                    />
                    <p className="text-xs text-gray-500">Used for time-based estimations.</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Minimum Project Fee ($)</Label>
                    <Input type="number" defaultValue={500} />
                    <p className="text-xs text-gray-500">Minimum amount to charge for any project.</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Cost Per Screen/Page ($)</Label>
                    <Input type="number" defaultValue={200} />
                    <p className="text-xs text-gray-500">Base cost for each unique screen design.</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Revision Cost ($/hour)</Label>
                    <Input type="number" defaultValue={85} />
                  </div>
                </div>
                
                <div className="flex items-center justify-between space-x-2 border p-4 rounded-md bg-gray-50">
                  <div className="space-y-0.5">
                    <Label className="text-base">Rush Fee</Label>
                    <p className="text-sm text-gray-500">Automatically add 20% for urgent timelines</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="multipliers">
            <Card>
              <CardHeader>
                <CardTitle>Complexity Multipliers</CardTitle>
                <CardDescription>Adjust costs based on project type difficulty.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 gap-4">
                  <div className="flex items-center gap-4">
                    <Label className="w-48">Web Application</Label>
                    <div className="flex-1">
                      <Input type="number" step="0.1" defaultValue={1.0} />
                    </div>
                    <span className="text-sm text-gray-500 w-12">x</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <Label className="w-48">Mobile App (Native)</Label>
                    <div className="flex-1">
                      <Input type="number" step="0.1" defaultValue={1.3} />
                    </div>
                    <span className="text-sm text-gray-500 w-12">x</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <Label className="w-48">Landing Page</Label>
                    <div className="flex-1">
                      <Input type="number" step="0.1" defaultValue={0.5} />
                    </div>
                    <span className="text-sm text-gray-500 w-12">x</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <Label className="w-48">Backend API</Label>
                    <div className="flex-1">
                      <Input type="number" step="0.1" defaultValue={0.8} />
                    </div>
                    <span className="text-sm text-gray-500 w-12">x</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="integrations">
            <Card>
              <CardHeader>
                <CardTitle>Integration Costs</CardTitle>
                <CardDescription>Flat fees for common third-party integrations.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "User Authentication", price: 300 },
                    { name: "Payment Processing (Stripe)", price: 500 },
                    { name: "Google Maps", price: 250 },
                    { name: "CMS Integration", price: 400 },
                    { name: "Analytics Setup", price: 150 },
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-4 border-b pb-4 last:border-0 last:pb-0">
                      <Label className="flex-1">{item.name}</Label>
                      <div className="w-32 relative">
                        <span className="absolute left-3 top-2.5 text-gray-500 text-sm">$</span>
                        <Input className="pl-6" type="number" defaultValue={item.price} />
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" className="w-full mt-4">
                    <Plus className="h-4 w-4 mr-2" /> Add Custom Integration
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
