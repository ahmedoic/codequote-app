import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2, Zap, Shield, DollarSign } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-2 font-bold text-xl text-blue-600">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
                Q
              </div>
              CodeQuote
            </div>
            <div className="flex items-center gap-4">
              <Button asChild variant="ghost" className="text-gray-600">
                <Link href="/dashboard">Freelancer Login</Link>
              </Button>
              <Button asChild className="bg-blue-600 hover:bg-blue-700">
                <Link href="/request">Start a Project</Link>
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative overflow-hidden pt-16 pb-32 space-y-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
              <span className="block">Software estimates,</span>
              <span className="block text-blue-600">simplified.</span>
            </h1>
            <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
              Get accurate, transparent quotes for your next software project in minutes. 
              For freelancers and agencies who want to close deals faster.
            </p>
            <div className="mt-10 flex justify-center gap-4">
              <Button asChild size="lg" className="px-8 h-12 text-base bg-blue-600 hover:bg-blue-700">
                <Link href="/request">
                  Get an Estimate <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="px-8 h-12 text-base">
                <Link href="/dashboard">
                  I'm a Freelancer
                </Link>
              </Button>
            </div>
          </div>
        </div>

        {/* Feature Grid */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                icon: <Zap className="h-6 w-6 text-yellow-500" />,
                title: "Instant Estimates",
                desc: "Real-time cost calculation based on project requirements."
              },
              {
                icon: <Shield className="h-6 w-6 text-green-500" />,
                title: "Transparent Pricing",
                desc: "Detailed breakdown of every feature and cost."
              },
              {
                icon: <DollarSign className="h-6 w-6 text-blue-500" />,
                title: "Fair Rates",
                desc: "Standardized pricing rules for consistent quotes."
              },
              {
                icon: <CheckCircle2 className="h-6 w-6 text-purple-500" />,
                title: "Professional Quotes",
                desc: "Beautifully generated PDF proposals ready to sign."
              }
            ].map((feature, i) => (
              <div key={i} className="bg-gray-50 rounded-xl p-6 hover:bg-gray-100 transition-colors">
                <div className="w-12 h-12 bg-white rounded-lg shadow-sm flex items-center justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-lg font-bold text-gray-900">{feature.title}</h3>
                <p className="mt-2 text-sm text-gray-500">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-50 border-t border-gray-200 mt-auto py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center gap-2 font-bold text-lg text-gray-400">
            CodeQuote
          </div>
          <p className="text-gray-400 text-sm">© 2024 CodeQuote. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
