import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Download, Share2, Printer, Save, ArrowLeft, Trash2, Plus, RefreshCw, Settings } from "lucide-react";
import { Link } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

export default function QuoteBuilder() {
  const [items, setItems] = useState([
    { id: 1, description: "Authentication Module (Login/Register)", hours: 12, rate: 85, total: 1020 },
    { id: 2, description: "Dashboard UI Implementation", hours: 24, rate: 85, total: 2040 },
    { id: 3, description: "Stripe Payment Integration", hours: 16, rate: 85, total: 1360 },
  ]);

  const addItem = () => {
    const newItem = {
      id: Date.now(),
      description: "New Line Item",
      hours: 1,
      rate: 85,
      total: 85
    };
    setItems([...items, newItem]);
  };

  const updateItem = (id: number, field: string, value: any) => {
    setItems(items.map(item => {
      if (item.id === id) {
        const updated = { ...item, [field]: value };
        // Recalculate total if hours or rate changes
        if (field === 'hours' || field === 'rate') {
          updated.total = Number(updated.hours) * Number(updated.rate);
        }
        return updated;
      }
      return item;
    }));
  };

  const removeItem = (id: number) => {
    setItems(items.filter(item => item.id !== id));
  };

  const subtotal = items.reduce((sum, item) => sum + item.total, 0);
  const tax = subtotal * 0.0; // 0% for freelance usually, but configurable
  const total = subtotal + tax;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Bar */}
      <header className="bg-white border-b px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-lg font-semibold flex items-center gap-2">
              Quote #Q-2024-042
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Draft</Badge>
            </h1>
            <p className="text-xs text-gray-500">Last saved 2 mins ago</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Save className="h-4 w-4 mr-2" />
            Save Draft
          </Button>
          <Button variant="default" size="sm" className="bg-blue-600 hover:bg-blue-700">
            <Share2 className="h-4 w-4 mr-2" />
            Send to Client
          </Button>
        </div>
      </header>

      <div className="max-w-5xl mx-auto p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Editor Column */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Client Info */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-base">Client Details</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Client Name</Label>
                <Input defaultValue="Acme Corp" />
              </div>
              <div className="space-y-2">
                <Label>Contact Email</Label>
                <Input defaultValue="billing@acme.com" />
              </div>
              <div className="col-span-2 space-y-2">
                <Label>Address (Optional)</Label>
                <Textarea className="h-20" placeholder="Client billing address..." />
              </div>
            </CardContent>
          </Card>

          {/* Line Items */}
          <Card>
            <CardHeader className="pb-4 flex flex-row items-center justify-between">
              <CardTitle className="text-base">Line Items</CardTitle>
              <Button variant="outline" size="sm" onClick={addItem}>
                <Plus className="h-4 w-4 mr-2" />
                Add Item
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {items.map((item) => (
                <div key={item.id} className="grid grid-cols-12 gap-2 items-start border-b pb-4 last:border-0 last:pb-0">
                  <div className="col-span-6">
                    <Label className="text-xs text-gray-500 mb-1 block">Description</Label>
                    <Input 
                      value={item.description} 
                      onChange={(e) => updateItem(item.id, 'description', e.target.value)}
                    />
                  </div>
                  <div className="col-span-2">
                    <Label className="text-xs text-gray-500 mb-1 block">Hours</Label>
                    <Input 
                      type="number" 
                      value={item.hours} 
                      onChange={(e) => updateItem(item.id, 'hours', Number(e.target.value))}
                    />
                  </div>
                  <div className="col-span-2">
                    <Label className="text-xs text-gray-500 mb-1 block">Rate ($)</Label>
                    <Input 
                      type="number" 
                      value={item.rate} 
                      onChange={(e) => updateItem(item.id, 'rate', Number(e.target.value))}
                    />
                  </div>
                  <div className="col-span-1">
                    <Label className="text-xs text-gray-500 mb-1 block">Total</Label>
                    <div className="h-10 flex items-center font-medium text-gray-700">
                      ${item.total}
                    </div>
                  </div>
                  <div className="col-span-1 flex justify-end pt-6">
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-red-400 hover:text-red-600 hover:bg-red-50" onClick={() => removeItem(item.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              
              <div className="flex justify-end pt-4">
                <div className="w-64 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Subtotal:</span>
                    <span className="font-medium">${subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Tax (0%):</span>
                    <span className="font-medium">$0.00</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total:</span>
                    <span>${total.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Terms */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-base">Notes & Terms</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea 
                className="h-32 font-mono text-sm" 
                defaultValue={`1. Payment Terms: 50% upfront, 50% upon completion.\n2. Timeline: Estimated 4 weeks from start date.\n3. Validity: This quote is valid for 14 days.`}
              />
            </CardContent>
          </Card>
        </div>

        {/* Preview Column */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 space-y-4">
            <Card className="bg-gray-800 text-white border-none overflow-hidden">
              <CardHeader className="bg-gray-900/50 pb-4">
                <CardTitle className="text-sm font-medium text-gray-400">Live Preview</CardTitle>
              </CardHeader>
              <CardContent className="p-6 text-sm">
                {/* Mini PDF Preview Look */}
                <div className="bg-white text-gray-900 p-4 rounded-sm shadow-lg origin-top transform scale-100 transition-transform">
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <div className="font-bold text-lg text-blue-600">CodeQuote</div>
                      <div className="text-[10px] text-gray-500 mt-1">Freelance Development</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-sm">QUOTE</div>
                      <div className="text-[10px] text-gray-500">#Q-2024-042</div>
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <div className="text-[10px] font-bold text-gray-400 mb-1">BILL TO</div>
                    <div className="font-medium text-xs">Acme Corp</div>
                    <div className="text-[10px] text-gray-500">billing@acme.com</div>
                  </div>

                  <table className="w-full mb-6">
                    <thead>
                      <tr className="border-b border-gray-200 text-[10px] text-gray-500 text-left">
                        <th className="pb-1 font-medium">DESCRIPTION</th>
                        <th className="pb-1 font-medium text-right">AMOUNT</th>
                      </tr>
                    </thead>
                    <tbody className="text-[10px]">
                      {items.map(item => (
                        <tr key={item.id} className="border-b border-gray-50">
                          <td className="py-2">{item.description}</td>
                          <td className="py-2 text-right">${item.total}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  <div className="flex justify-end border-t border-gray-200 pt-2">
                    <div className="text-right">
                      <div className="text-[10px] text-gray-500">Total</div>
                      <div className="font-bold text-sm text-blue-600">${total.toLocaleString()}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-gray-900/50 border-t border-gray-700 flex justify-between">
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white hover:bg-gray-800">
                  <Printer className="h-4 w-4 mr-2" /> Print
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white hover:bg-gray-800">
                  <Download className="h-4 w-4 mr-2" /> PDF
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Reset to Template
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Settings className="h-4 w-4 mr-2" />
                  Edit Pricing Rules
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
